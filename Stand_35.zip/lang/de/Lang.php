<?php

/*
 *  
 *  Diese Datei enth�lt grundlegende Informationen �ber die Sprach-Dateien, z.B. den Namen, Version, Author, usw. 
 * 
*/

$lang['de']['info']['version'] = 1.0;
$lang['de']['info']['author'] = "Author";
$lang['de']['info']['copyright'] = "&copy; JuKu; http://developertalk.de";
$lang['de']['info']['name'] = "Deutsch";
$lang['de']['info']['shortname'] = "de";

?>