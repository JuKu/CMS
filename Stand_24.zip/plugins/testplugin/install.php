class Testplugin {

public function install () {
	//
}

public function deinstall () {
	//
}

}