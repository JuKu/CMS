<?php

$pluginname = "testplugin";
$plugin[$pluginname]['info']['name'] = "testplugin";

?>