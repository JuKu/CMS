<h2>Einloggen</h2>
<br />
<form action="index.php?option=login" method="post">
<table border="0">
<tr>
<td width="200">Benutzername</td>
<td width="200"><input type="text" name="user" /></td>
</tr>
<tr>
<td width="200">Passwort</td>
<td width="200"><input type="password" name="passwort" /></td>
</tr>
</table>
<br /><br />
<input type="submit" name="Absendem" value="Login" />
</form>