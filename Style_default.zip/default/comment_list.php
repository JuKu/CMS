<table border="1">
    <tr>
        <td>
            <a href="{HREF}">{AUTHOR}</a><br />
            {DATE}
        </td>
        <td>
            {CONTENT}
        </td>
    </tr>
</table>