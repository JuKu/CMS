<?php

class SkinController {
    
    public function getSelectedSkin () {
        return Settings::getSetting("selectedskin");
    }
    
    public function getSkinPath () {
    
    if (!file_exists("Cache")) {
        mkdir("Cache");
    }
    
    if (!file_exists("Cache/styles")) {
        mkdir("Cache/styles");
    }
    
    if (!file_exists("Cache/styles/" . SkinController::getSelectedSkin())) {
        mkdir("Cache/styles/" . SkinController::getSelectedSkin());
    }
    
    if (!file_exists("Cache/styles/" . SkinController::getSelectedSkin() . "/index.php")) {
    
        $handle = fopen ("styles/" . SkinController::getSelectedSkin() . "/index.php", "r");
        
        $text = "";
        
        while (!feof($handle)) {
        $buffer = fgets($handle);
        $text .= $buffer;
        }
        
        fclose ($handle);
        
        $text = str_replace("{CONTENT}", SkinController::PHPCode("$" . "page->getContent()"), $text);
        $text = str_replace("{STYLE}", SkinController::PHPCode("echo Settings::getSetting(\"selectedskin\");"), $text);
        
        $handle = fopen ("Cache/styles/" . SkinController::getSelectedSkin() . "/index.php", "w");
        
        fwrite($handle, $text);
        
        fclose($handle);
        
        return "Cache/styles/" . SkinController::getSelectedSkin();
        
    } else {
        return "Cache/styles/" . SkinController::getSelectedSkin();
    }

    }
    
    public function PHPCode ($text) {
        return "<" . "?" . "php " . $text . " ?" . ">";
    }
    
}

?>