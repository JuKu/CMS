<?php

class Page {
    
    public function getHeader () {
        return "";
    }
    
    public function getTitle () {
        return "Titel";
    }
    
    public function getContent () {
        echo "Content";
    }
    
}

?>