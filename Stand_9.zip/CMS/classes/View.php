<?php

class View {

private $style_path = "";

    public function View ($style_path) {
        $this->style_path = $style_path;
    }
    
    public function showPage () {
    
    global $page;
        
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\r\n\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de\">\r\n<head>\r\n";
        echo "<title>" . $page->getTitle() . "</title>\r\n";
        echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />\r\n";
        echo "</head>\r\n";
        echo "<body>\r\n";
        
        require($this->style_path);
        
        echo "\r\n</body>\r\n</html>";
        
    }
    
}

?>