<?php

class Menu {
    
    public function getMenu () {
    
    global $db;
        
        $globalmenuID = 1;
        
        $sql = "SELECT * FROM `menu` WHERE `menuID` = '" . $globalmenuID . "' AND `activated` = '1'; ";
        
        $db_erg = $db->query($sql) or die("Anfrage fehlgeschlagen.");
        
        $skincontroller = new SkinController();//Wird eig. nur statisch aufgrerufen, de�halb muss erst einmal ein Objekt erstellt werden.
        
        while ($zeile = $db->fetch_array($db_erg, MYSQL_ASSOC)) {
            $skincontroller->showMenu($zeile['href'], $zeile['content'], $zeile['id'], $zeile['menuID']);
        }
        
    }
    
}

?>