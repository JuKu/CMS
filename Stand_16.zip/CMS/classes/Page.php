<?php

class Page {

    var $id = -1;
    var $alias = '';
    var $title = '';
    var $gesperrt = -1;
    var $editable = -1;
    var $activated = -1;
    var $owner = -1;
    var $menu = -1;
    
    public function Page () {
        
        if (!isset($_REQUEST['include'])) {
            $this->alias = "Startseite";
        } else {
            $this->alias = $_REQUEST['include'];
        }
        
        $this->loadPage();
        
    }
    
    public function loadPage () {
    
    global $db;
        
        $sql = "SELECT * FROM `pages` WHERE `alias` = '" . $db->escape($this->alias) . "'; ";
        
        $db_erg = $db->query($sql) or die("Anfrage fehlgeschlagen.");//Fehlerbehebung mit Exceptions, ... kommt sp�ter.
        
        $i = 0;
        
        while ($zeile = $db->fetch_array($db_erg, MYSQL_ASSOC)) {
            $this->id = $zeile['id'];
            $this->title = $zeile['title'];
            $this->gesperrt = $zeile['gesperrt'];
            $this->editable = $zeile['editable'];
            $this->activated = $zeile['activated'];
            $this->owner = $zeile['owner'];
            $this->alias = $zeile['alias'];
            $this->menu = $zeile['menu'];
            
            $i = $i + 1;
        }
        
        if ($i == 0) {//Seite ist nicht in der Datenbank "registriert".
            $this->alias = "404";//Seite wurde nicht gefunden.
            $this->loadPage();//Dieselbe Methode nochmal aufrufen, um die 404-Seite zu laden.
        }
        
        if ($i > 1) {//Seite ist mehrmals in der Datenbank vorhanden.
            //Ins Fehler-Protokoll schreiben (wird sp�ter geschrieben).
        }
        
    }
    
    public function getHeader () {
    
    global $db;
        
        $sql = "SELECT * FROM `cms_meta_global`";
        
        $db_erg = $db->query($sql) or die("Anfrage fehlgeschlagen.");
        
        $meta_tags = "";
        
        while ($zeile = $db->fetch_array($db_erg, MYSQL_ASSOC)) {
            $meta_tags = $meta_tags . "<meta name=\"" . $zeile['name'] . "\" content=\"" . $zeile['content'] . "\" />\r\n";
        }
        
        echo $meta_tags;
    }
    
    public function getTitle () {
        return $this->title;
    }
    
    public function getContent () {
    
        $filename = $this->alias;
        
        $file = preg_replace("/[^a-z0-9\-\/]/i","",$filename);
        if(isset($file[0]) && $file[0] == "/"){
            $file = substr($filename,1);
        }
        
        $file = "Content/pages/" . $file;
        $file .= ".php";
        
        if(!file_exists($file)){
            $file = "Content/pages/404.php";
            $this->alias = "404";
            $this->loadPage();//Seite 404.php laden.
            $this->getContent();//Methode erneuert aufrufen.   
        } else {
            require($file); 
        }   
        
    }
    
    public function getMenu () {
        $menu = new Menu();
        $menu->getMenu();
    }
    
}

?>