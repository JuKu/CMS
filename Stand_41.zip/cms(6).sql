-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 22. Mrz 2012 um 16:48
-- Server Version: 5.5.16
-- PHP-Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `cms`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_admin_menu`
--

CREATE TABLE IF NOT EXISTS `cms_admin_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  `file` varchar(800) NOT NULL,
  `activated` int(10) NOT NULL DEFAULT '1',
  `Modul` varchar(600) NOT NULL,
  `Ownermenu` int(10) NOT NULL DEFAULT '-1',
  `showNumber` int(10) NOT NULL DEFAULT '1',
  `expand` int(10) NOT NULL DEFAULT '0',
  `isEditable` int(10) NOT NULL DEFAULT '1',
  `PluginMenu` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `cms_admin_menu`
--

INSERT INTO `cms_admin_menu` (`id`, `name`, `file`, `activated`, `Modul`, `Ownermenu`, `showNumber`, `expand`, `isEditable`, `PluginMenu`) VALUES
(1, '{GENERAL}', 'Fehler_404.php', 1, '-', -1, 1, 1, 0, 0),
(2, '{SETTINGS}', 'Settings.php', 1, 'Settings', 1, 2, 0, 0, 0),
(3, 'Dashboard', 'Dashboard', 1, 'Dashboard', 1, 1, 0, 1, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_dashboard_widgets`
--

CREATE TABLE IF NOT EXISTS `cms_dashboard_widgets` (
  `id` int(10) NOT NULL,
  `col` int(10) NOT NULL,
  `row` int(10) NOT NULL AUTO_INCREMENT,
  `path` varchar(600) NOT NULL,
  `PluginWidget` int(10) NOT NULL DEFAULT '-1',
  `activated` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`row`,`id`,`col`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `cms_dashboard_widgets`
--

INSERT INTO `cms_dashboard_widgets` (`id`, `col`, `row`, `path`, `PluginWidget`, `activated`) VALUES
(1, 1, 1, 'widgets/Welcome.php', -1, 1),
(1, 1, 2, 'widgets/Widget_Log.php', -1, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_events`
--

CREATE TABLE IF NOT EXISTS `cms_events` (
  `event` varchar(255) NOT NULL,
  `file` varchar(600) NOT NULL,
  `pluginEvent` int(10) NOT NULL DEFAULT '0',
  `page` int(10) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`event`,`file`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_iconsets`
--

CREATE TABLE IF NOT EXISTS `cms_iconsets` (
  `name` varchar(600) NOT NULL,
  `path` varchar(600) NOT NULL,
  `copyright` varchar(800) NOT NULL,
  `lizenz_text` text,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `cms_iconsets`
--

INSERT INTO `cms_iconsets` (`name`, `path`, `copyright`, `lizenz_text`) VALUES
('famfamfam_silk_icons', 'images/iconsets/famfamfam_silk_icons', 'http://www.famfamfam.com/lab/icons/silk/', 'License<br /><br />\r\n\r\nI also love to hear of my work being used, feel encouraged to send an email with a link or screenshot of the icons in their new home to mjames at gmail dot com. This work is licensed under a Creative Commons Attribution 2.5 License. This means you may use it for any purpose, and make any changes you like. All I ask is that you include a link back to this page in your credits (although a giant link on every page of your website really isn''t needed, contact me to discuss specifics).<br /><br />\r\n\r\nThe icons can also be used under Creative Commons Attribution 3.0 License (Hi Debian folks!) with the following requirements:<br /><br />\r\n\r\n    As an author, I would appreciate a reference to my authorship of the Silk icon set contents within a readme file or equivalent documentation for the software which includes the set or a subset of the icons contained within. ');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_log`
--

CREATE TABLE IF NOT EXISTS `cms_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(600) NOT NULL,
  `text` text NOT NULL,
  `activated` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `cms_log`
--

INSERT INTO `cms_log` (`id`, `user`, `text`, `activated`) VALUES
(1, 'System', 'Widget "Welcome" hinzugefügt.', 1),
(2, 'System', 'Widget "Widget_Log" hinzugef&uuml;gt.', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_meta_global`
--

CREATE TABLE IF NOT EXISTS `cms_meta_global` (
  `name` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `cms_meta_global`
--

INSERT INTO `cms_meta_global` (`name`, `content`) VALUES
('author', 'Autor'),
('description', 'Beschreibung der Seite');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_meta_local`
--

CREATE TABLE IF NOT EXISTS `cms_meta_local` (
  `name` varchar(100) NOT NULL,
  `page` int(10) NOT NULL,
  `content` varchar(100) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_packages`
--

CREATE TABLE IF NOT EXISTS `cms_packages` (
  `name` varchar(600) NOT NULL,
  `version` decimal(10,1) NOT NULL DEFAULT '1.0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `cms_packages`
--

INSERT INTO `cms_packages` (`name`, `version`) VALUES
('cms_core', 1.0),
('inettuts', 1.0),
('language-pack_de', 1.0),
('language-pack_en', 1.0),
('plugin_updater', 1.0),
('widget_log', 1.0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_settings`
--

CREATE TABLE IF NOT EXISTS `cms_settings` (
  `property` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `activated` int(4) NOT NULL DEFAULT '1',
  `is_editable` int(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`property`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `cms_settings`
--

INSERT INTO `cms_settings` (`property`, `value`, `activated`, `is_editable`) VALUES
('selectedskin', 'default', 1, 1),
('language_token', 'de', 1, 1),
('title', 'Seitentitel-test', 1, 1),
('icon_set', 'famfamfam_silk_icons', 1, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_users`
--

CREATE TABLE IF NOT EXISTS `cms_users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  `password` varchar(600) NOT NULL,
  `activated` int(10) NOT NULL DEFAULT '1',
  `admin` int(10) NOT NULL DEFAULT '1',
  `regist` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `cms_users`
--

INSERT INTO `cms_users` (`id`, `name`, `password`, `activated`, `admin`, `regist`) VALUES
(1, 'Admin', '16d7a4fca7442dda3ad93c9a726597e4', 1, 1, '2012-03-17 15:01:01');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cms_widgets`
--

CREATE TABLE IF NOT EXISTS `cms_widgets` (
  `name` varchar(255) NOT NULL,
  `path` varchar(600) NOT NULL,
  `class` varchar(255) NOT NULL,
  `activated` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `cms_widgets`
--

INSERT INTO `cms_widgets` (`name`, `path`, `class`, `activated`) VALUES
('Welcome', 'widgets/Welcome.php', 'Welcome', 1),
('Widget_Log', 'widgets/Widget_Log.php', 'Widget_Log', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `menuID` int(10) NOT NULL DEFAULT '1',
  `content` varchar(600) NOT NULL,
  `href` varchar(800) NOT NULL,
  `activated` int(10) NOT NULL DEFAULT '1',
  `owner` int(10) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`,`menuID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Daten für Tabelle `menu`
--

INSERT INTO `menu` (`id`, `menuID`, `content`, `href`, `activated`, `owner`) VALUES
(1, 1, 'Startseite / Home', 'Startseite.html', 1, -1),
(2, 1, 'Testseite', 'Testseite.html', 1, -1),
(3, 1, 'Testseite', 'Testseite2.html', 1, 2),
(4, 1, 'Testseite', 'Testseite.html', 1, 2),
(5, 1, 'Admin-Bereich', 'admin', 1, -1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `gesperrt` int(10) DEFAULT '0',
  `editable` int(10) NOT NULL DEFAULT '1',
  `activated` int(10) NOT NULL DEFAULT '1',
  `owner` int(11) NOT NULL DEFAULT '-1',
  `menu` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Daten für Tabelle `pages`
--

INSERT INTO `pages` (`id`, `alias`, `title`, `gesperrt`, `editable`, `activated`, `owner`, `menu`) VALUES
(1, 'Startseite', 'Startseite', 0, 1, 1, -1, -1),
(2, '404', 'Fehler 404', 0, 1, 1, -1, -1),
(3, 'Testseite', 'Testseite', 0, 1, 1, 1, -1),
(4, 'Testseite2', 'Testseite2', 0, 1, 1, 3, -1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `plugins`
--

CREATE TABLE IF NOT EXISTS `plugins` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `styles`
--

CREATE TABLE IF NOT EXISTS `styles` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `styles`
--

INSERT INTO `styles` (`id`, `name`) VALUES
(1, 'default');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `test` int(10) NOT NULL AUTO_INCREMENT,
  `test2` varchar(600) NOT NULL,
  PRIMARY KEY (`test`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
