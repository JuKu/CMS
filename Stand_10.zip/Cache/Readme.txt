Diese datei k�nnt ihr l�schen.
Sie wurde nur angelegt, weil man den ordner sonst nicht archivieren kann.