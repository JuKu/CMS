<?php

class Page {
    
    public function getHeader () {
        return "Header";
    }
    
    public function getTitle () {
        return "Titel";
    }
    
    public function getContent () {
    
        if (!isset($_REQUEST['include'])) {
            $filename = "Startseite";
        } else {
            $filename = $_REQUEST['include'];
        }
        
        $file = preg_replace("/[^a-z0-9\-\/]/i","",$filename);
        if(isset($file[0]) && $file[0] == "/"){
            $file = substr($filename,1);
        }
        
        $file = "Content/pages/" . $file;
        $file .= ".php";
        
        if(!file_exists($file)){
            $file = "Content/pages/404.php";
        }
        
        require($file);    
        
    }
    
}

?>