<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN\" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de">
<head>
<title>{TITLE}</title>
{HEADER}
<style type="text/css">
body {
    background-color:#9AD7FF;
    color:#002EFF;
}
</style>
</head>
<body>
<b>Ihr ausgew&auml;hlter Style: {STYLE}</b><br />
<hr /><br />
{CONTENT}
</body>
</html>